import React from 'react';
import { MapPin } from 'lucide-react';
import { format } from 'date-fns';

const DEPT_LABELS = {
  emergency: 'Emergency',
  icu: 'ICU',
  surgery: 'Surgery',
  radiology: 'Radiology',
  cardiology: 'Cardiology',
  pediatrics: 'Pediatrics',
  oncology: 'Oncology',
  neurology: 'Neurology',
  orthopedics: 'Orthopedics',
  general_ward: 'General Ward',
  outpatient: 'Outpatient',
  storage: 'Storage',
};

export default function RecentActivity({ locationHistory, assets }) {
  const assetMap = {};
  assets.forEach(a => { assetMap[a.asset_id] = a; });

  const recent = locationHistory.slice(0, 8);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4">Recent Movements</h3>
      {recent.length === 0 ? (
        <p className="text-sm text-muted-foreground py-6 text-center">No recent activity</p>
      ) : (
        <div className="space-y-3">
          {recent.map((entry, i) => {
            const asset = assetMap[entry.asset_id];
            return (
              <div key={entry.id || i} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <MapPin className="w-3.5 h-3.5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {asset?.asset_name || entry.asset_id}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    → {DEPT_LABELS[entry.department] || entry.department}, Floor {entry.floor}
                    {entry.zone && `, ${entry.zone}`}
                  </p>
                </div>
                <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                  {entry.created_date ? format(new Date(entry.created_date), 'h:mm a') : ''}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}