import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Battery, Clock, Wrench, HelpCircle, ShieldAlert } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const alertIcons = {
  low_battery: Battery,
  idle_too_long: Clock,
  maintenance_due: Wrench,
  maintenance_flagged: Wrench,
  missing: HelpCircle,
  zone_breach: ShieldAlert,
};

const severityStyles = {
  low: 'bg-secondary text-secondary-foreground',
  medium: 'bg-amber-100 text-amber-800',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800',
};

export default function RecentAlerts({ alerts, onViewAll }) {
  const recent = alerts.filter(a => a.status === 'active').slice(0, 5);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">Active Alerts</h3>
        {onViewAll ? (
          <button onClick={onViewAll} className="text-xs font-medium text-primary hover:underline">View all</button>
        ) : (
          <Link to="/Alerts" className="text-xs font-medium text-primary hover:underline">View all</Link>
        )}
      </div>
      {recent.length === 0 ? (
        <p className="text-sm text-muted-foreground py-6 text-center">No active alerts</p>
      ) : (
        <div className="space-y-3">
          {recent.map(alert => {
            const Icon = alertIcons[alert.alert_type] || AlertTriangle;
            return (
              <div key={alert.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                <div className="w-8 h-8 rounded-lg bg-destructive/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Icon className="w-4 h-4 text-destructive" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{alert.asset_name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{alert.message}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <Badge className={cn("text-[10px] px-1.5 py-0", severityStyles[alert.severity])}>
                      {alert.severity}
                    </Badge>
                    <span className="text-[10px] text-muted-foreground">
                      {format(new Date(alert.created_date), 'MMM d, h:mm a')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}