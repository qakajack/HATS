import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import AssetStatusBadge from '../assets/AssetStatusBadge';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DEPT_LABELS = {
  emergency: 'Emergency', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardiology', pediatrics: 'Pediatrics', oncology: 'Oncology',
  neurology: 'Neurology', orthopedics: 'Orthopedics', general_ward: 'General Ward',
  outpatient: 'Outpatient', storage: 'Storage',
};

export default function AssetDrilldownModal({ title, assets, open, onOpenChange }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>{title} <span className="text-muted-foreground font-normal text-sm ml-2">({assets.length} assets)</span></DialogTitle>
        </DialogHeader>
        <div className="overflow-y-auto flex-1">
          {assets.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-8">No assets in this category.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Asset</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Movement</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.map(asset => (
                  <TableRow key={asset.id}>
                    <TableCell className="font-medium text-sm">{asset.asset_name}</TableCell>
                    <TableCell className="text-xs font-mono text-muted-foreground">{asset.asset_id}</TableCell>
                    <TableCell className="text-sm">{DEPT_LABELS[asset.department] || asset.department || '—'}</TableCell>
                    <TableCell><AssetStatusBadge status={asset.status} /></TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {asset.last_seen
                        ? formatDistanceToNow(new Date(asset.last_seen), { addSuffix: true })
                        : '—'}
                    </TableCell>
                    <TableCell>
                      <Button asChild size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1">
                        <Link to={`/FloorMap?asset=${asset.asset_id}&floor=${asset.floor || '1'}`}>
                          <MapPin className="w-3 h-3" /> Locate
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}