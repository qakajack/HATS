import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const DEPT_LABELS = {
  emergency: 'ER',
  icu: 'ICU',
  surgery: 'Surgery',
  radiology: 'Radiology',
  cardiology: 'Cardio',
  pediatrics: 'Peds',
  oncology: 'Onco',
  neurology: 'Neuro',
  orthopedics: 'Ortho',
  general_ward: 'General',
  outpatient: 'Outpat.',
  storage: 'Storage',
};

const COLORS = [
  'hsl(199, 89%, 48%)', 'hsl(172, 66%, 50%)', 'hsl(262, 52%, 55%)',
  'hsl(43, 96%, 56%)', 'hsl(0, 72%, 51%)', 'hsl(199, 89%, 65%)',
  'hsl(172, 66%, 65%)', 'hsl(262, 52%, 70%)', 'hsl(43, 96%, 70%)',
  'hsl(330, 65%, 55%)', 'hsl(190, 60%, 45%)', 'hsl(120, 40%, 50%)',
];

export default function DepartmentChart({ assets, onBarClick }) {
  const deptData = {};
  assets.forEach(a => {
    if (a.department) {
      deptData[a.department] = (deptData[a.department] || 0) + 1;
    }
  });

  const data = Object.entries(deptData)
    .map(([dept, count]) => ({
      name: DEPT_LABELS[dept] || dept,
      department: dept,
      count
    }))
    .sort((a, b) => b.count - a.count);

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4">Assets by Department</h3>
      <div className="h-[240px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
            <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{
                background: 'hsl(0 0% 100%)',
                border: '1px solid hsl(214 20% 90%)',
                borderRadius: '8px',
                fontSize: '12px',
              }}
            />
            <Bar
              dataKey="count"
              radius={[6, 6, 0, 0]}
              onClick={(data) => onBarClick?.(data.department)}
              style={{ cursor: 'pointer' }}
            >
              {data.map((_, idx) => (
                <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}