import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const STATUS_CONFIG = {
  available: { label: 'Available', color: 'hsl(172, 66%, 50%)' },
  in_use: { label: 'In Use', color: 'hsl(199, 89%, 48%)' },
  maintenance: { label: 'Maintenance', color: 'hsl(43, 96%, 56%)' },
  decommissioned: { label: 'Decommissioned', color: 'hsl(215, 13%, 50%)' },
  missing: { label: 'Missing', color: 'hsl(0, 72%, 51%)' },
};

export default function StatusPieChart({ assets, onSliceClick }) {
  const statusData = {};
  assets.forEach(a => {
    const s = a.status || 'available';
    statusData[s] = (statusData[s] || 0) + 1;
  });

  const data = Object.entries(statusData).map(([key, value]) => ({
    name: STATUS_CONFIG[key]?.label || key,
    status: key,
    value,
    color: STATUS_CONFIG[key]?.color || '#888',
  }));

  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <h3 className="text-sm font-semibold text-foreground mb-4">Status Distribution</h3>
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={3}
              dataKey="value"
              onClick={(data) => onSliceClick?.(data.status)}
              style={{ cursor: 'pointer' }}
            >
              {data.map((entry, idx) => (
                <Cell key={idx} fill={entry.color} stroke="none" />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                background: 'hsl(0 0% 100%)',
                border: '1px solid hsl(214 20% 90%)',
                borderRadius: '8px',
                fontSize: '12px',
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="flex flex-wrap gap-3 mt-2 justify-center">
        {data.map(d => (
          <div key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: d.color }} />
            {d.name} ({d.value})
          </div>
        ))}
      </div>
    </div>
  );
}