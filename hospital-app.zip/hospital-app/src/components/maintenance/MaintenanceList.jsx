import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Play, CheckCircle2, XCircle, Wrench } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

const statusConfig = {
  open: { label: 'Open', className: 'bg-blue-100 text-blue-700' },
  in_progress: { label: 'In Progress', className: 'bg-amber-100 text-amber-700' },
  completed: { label: 'Completed', className: 'bg-emerald-100 text-emerald-700' },
  cancelled: { label: 'Cancelled', className: 'bg-gray-100 text-gray-600' },
};

const priorityConfig = {
  low: { label: 'Low', className: 'bg-secondary text-secondary-foreground' },
  medium: { label: 'Medium', className: 'bg-amber-100 text-amber-700' },
  high: { label: 'High', className: 'bg-orange-100 text-orange-700' },
  urgent: { label: 'Urgent', className: 'bg-red-100 text-red-700' },
};

const typeLabels = {
  preventive: 'Preventive', corrective: 'Corrective', inspection: 'Inspection',
  calibration: 'Calibration', emergency: 'Emergency',
};

export default function MaintenanceList({ requests, isLoading, onUpdateStatus }) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
      </div>
    );
  }

  if (requests.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <Wrench className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
        <p className="text-muted-foreground">No maintenance requests found.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {requests.map(req => {
        const status = statusConfig[req.status] || statusConfig.open;
        const priority = priorityConfig[req.priority] || priorityConfig.medium;

        return (
          <div key={req.id} className="bg-card rounded-xl border border-border p-4 flex items-start gap-4 hover:shadow-sm transition-shadow">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Wrench className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm">{req.asset_name}</span>
                <Badge className={cn('text-[10px]', status.className)}>{status.label}</Badge>
                <Badge className={cn('text-[10px]', priority.className)}>{priority.label}</Badge>
                <Badge variant="outline" className="text-[10px]">{typeLabels[req.request_type] || req.request_type}</Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{req.description}</p>
              <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
                {req.assigned_to && <span>Assigned: {req.assigned_to}</span>}
                <span>{format(new Date(req.created_date), 'MMM d, yyyy')}</span>
              </div>
            </div>
            {req.status !== 'completed' && req.status !== 'cancelled' && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {req.status === 'open' && (
                    <DropdownMenuItem onClick={() => onUpdateStatus(req.id, 'in_progress')}>
                      <Play className="w-3.5 h-3.5 mr-2" /> Start Work
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => onUpdateStatus(req.id, 'completed')}>
                    <CheckCircle2 className="w-3.5 h-3.5 mr-2" /> Mark Complete
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onUpdateStatus(req.id, 'cancelled')}>
                    <XCircle className="w-3.5 h-3.5 mr-2" /> Cancel
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        );
      })}
    </div>
  );
}