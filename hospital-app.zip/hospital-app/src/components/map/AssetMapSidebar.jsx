import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import AssetStatusBadge from '../assets/AssetStatusBadge';
import EquipmentIcon from '../assets/EquipmentIcon';
import { format } from 'date-fns';
import { MapPin, Clock, Battery, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ReportBrokenDialog from './ReportBrokenDialog';

const DEPT_LABELS = {
  emergency: 'Emergency', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardiology', pediatrics: 'Pediatrics', oncology: 'Oncology',
  neurology: 'Neurology', orthopedics: 'Orthopedics', general_ward: 'General Ward',
  outpatient: 'Outpatient', storage: 'Storage',
};

export default function AssetMapSidebar({ assets, selectedAsset, onSelectAsset, onAssetUpdated }) {
  const [reportingAsset, setReportingAsset] = useState(null);

  return (
    <>
      {reportingAsset && (
        <ReportBrokenDialog
          asset={reportingAsset}
          open={!!reportingAsset}
          onClose={() => setReportingAsset(null)}
          onSuccess={() => { onAssetUpdated?.(); setReportingAsset(null); }}
        />
      )}

      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border">
          <h3 className="text-sm font-semibold text-foreground">Assets on Floor</h3>
          <p className="text-xs text-muted-foreground mt-0.5">{assets.length} items</p>
        </div>

        {/* Selected asset detail */}
        {selectedAsset && (
        <div className="p-4 border-b border-border bg-primary/5">
          <div className="flex items-center gap-2 mb-2">
            <EquipmentIcon type={selectedAsset.equipment_type} className="w-5 h-5 text-primary" />
            <h4 className="font-semibold text-sm text-foreground">{selectedAsset.asset_name}</h4>
          </div>
          <div className="space-y-1.5 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <span className="font-mono">{selectedAsset.asset_id}</span>
              <AssetStatusBadge status={selectedAsset.status} />
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3 h-3" />
              {DEPT_LABELS[selectedAsset.department] || selectedAsset.department}
              {selectedAsset.zone && ` · ${selectedAsset.zone}`}
            </div>
            {selectedAsset.last_seen && (
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3" />
                Last seen: {format(new Date(selectedAsset.last_seen), 'MMM d, h:mm a')}
              </div>
            )}
            {selectedAsset.battery_level != null && (
              <div className="flex items-center gap-1.5">
                <Battery className="w-3 h-3" />
                Battery: {selectedAsset.battery_level}%
              </div>
            )}
          </div>
          {selectedAsset.status !== 'maintenance' && selectedAsset.status !== 'decommissioned' && (
            <Button
              size="sm"
              variant="destructive"
              className="mt-3 w-full gap-1.5"
              onClick={() => setReportingAsset(selectedAsset)}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Report Broken
            </Button>
          )}
        </div>
        )}

        {/* Asset list */}
        <div className="max-h-[400px] overflow-y-auto">
          {assets.map(asset => (
            <button
              key={asset.id}
              onClick={() => onSelectAsset(asset)}
              className={cn(
                "w-full text-left px-4 py-2.5 border-b border-border/50 hover:bg-muted/50 transition-colors flex items-center gap-2.5",
                selectedAsset?.id === asset.id && "bg-primary/5"
              )}
            >
              <div className="w-6 h-6 rounded bg-muted flex items-center justify-center shrink-0">
                <EquipmentIcon type={asset.equipment_type} className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground truncate">{asset.asset_name}</p>
                <p className="text-[10px] text-muted-foreground">
                  {DEPT_LABELS[asset.department] || '—'} {asset.zone && `· ${asset.zone}`}
                </p>
              </div>
              <AssetStatusBadge status={asset.status} />
            </button>
          ))}
        </div>
      </div>
    </>
  );
}