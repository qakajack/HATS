import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { ZoomIn, ZoomOut, Maximize2, Play, Pause } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const STATUS_COLOR = {
  available: '#10b981',
  in_use: '#3b82f6',
  maintenance: '#f59e0b',
  missing: '#ef4444',
};

const STATUS_LABEL = {
  available: 'Available',
  in_use: 'In Use',
  maintenance: 'Maintenance',
  missing: 'Missing',
};

const DEPT_LABELS = {
  emergency: 'Emergency', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardiology', pediatrics: 'Pediatrics', oncology: 'Oncology',
  neurology: 'Neurology', orthopedics: 'Orthopedics', general_ward: 'General Ward',
  outpatient: 'Outpatient', storage: 'Storage',
};

function AssetTooltip({ asset, zoom }) {
  const lastMovement = asset.last_seen
    ? formatDistanceToNow(new Date(asset.last_seen), { addSuffix: true })
    : 'Unknown';
  const color = STATUS_COLOR[asset.status] || '#6b7280';

  const tooltipStyle = {
    position: 'fixed',
    zIndex: 9999,
    width: '220px',
    background: 'hsl(var(--card))',
    border: '1px solid hsl(var(--border))',
    borderRadius: '12px',
    boxShadow: '0 10px 40px rgba(0,0,0,0.15)',
    padding: '12px',
    pointerEvents: 'none',
    transform: `scale(${Math.max(0.8, 1 / zoom)})`,
    transformOrigin: 'top left',
  };

  return (
    <div style={tooltipStyle}>
      <div className="font-semibold text-sm text-foreground mb-1 truncate">{asset.asset_name}</div>
      <div className="text-xs text-muted-foreground font-mono mb-2">{asset.asset_id}</div>
      <div className="space-y-1">
        <div className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 rounded-full shrink-0" style={{ background: color }} />
          <span className="text-foreground">{STATUS_LABEL[asset.status] || asset.status}</span>
        </div>
        {asset.department && (
          <div className="text-xs text-muted-foreground">📍 {DEPT_LABELS[asset.department] || asset.department}</div>
        )}
        {asset.battery_level != null && (
          <div className="text-xs text-muted-foreground">🔋 {asset.battery_level}% battery</div>
        )}
        <div className="text-xs text-muted-foreground">🕒 {lastMovement}</div>
      </div>
    </div>
  );
}

const DEPARTMENT_LAYOUT = {
  emergency:    { x: 5,  y: 10, w: 25, h: 35, label: 'Emergency' },
  icu:          { x: 32, y: 10, w: 20, h: 35, label: 'ICU' },
  surgery:      { x: 55, y: 10, w: 22, h: 30, label: 'Surgery' },
  radiology:    { x: 80, y: 10, w: 16, h: 30, label: 'Radiology' },
  cardiology:   { x: 5,  y: 50, w: 20, h: 30, label: 'Cardiology' },
  pediatrics:   { x: 28, y: 50, w: 20, h: 30, label: 'Pediatrics' },
  oncology:     { x: 50, y: 45, w: 18, h: 25, label: 'Oncology' },
  neurology:    { x: 70, y: 45, w: 16, h: 25, label: 'Neurology' },
  orthopedics:  { x: 5,  y: 83, w: 22, h: 14, label: 'Orthopedics' },
  general_ward: { x: 30, y: 83, w: 25, h: 14, label: 'General Ward' },
  outpatient:   { x: 58, y: 75, w: 18, h: 22, label: 'Outpatient' },
  storage:      { x: 80, y: 75, w: 16, h: 22, label: 'Storage' },
};

function getAssetPosition(asset) {
  const dept = DEPARTMENT_LAYOUT[asset.department];
  if (!dept) return { x: 50, y: 50 };
  let hash = 0;
  const id = asset.asset_id || asset.id || '';
  for (let i = 0; i < id.length; i++) {
    hash = ((hash << 5) - hash) + id.charCodeAt(i);
    hash |= 0;
  }
  const px = Math.abs(hash % 70) / 100;
  const py = Math.abs((hash >> 8) % 70) / 100;
  return {
    x: dept.x + dept.w * 0.15 + dept.w * 0.7 * px,
    y: dept.y + dept.h * 0.3 + dept.h * 0.5 * py,
  };
}

export default function FloorMapView({ assets, floor, floorLabel, mapUrl, mapImages, selectedAsset, onSelectAsset, highlightAssetId, isLoading }) {
  const [zoom, setZoom] = useState(0);
  const [zoomInput, setZoomInput] = useState('0');
  const [pan, setPan] = useState({ x: 0, y: 0 });

  const clampPan = useCallback((newPan, scale) => {
    if (!containerRef.current || !mapImages || mapImages.length === 0) return newPan;
    const cw = containerRef.current.offsetWidth;
    const ch = containerRef.current.offsetHeight;
    const maxX = Math.max(0, (scale - 1) * cw / 2);
    const maxY = Math.max(0, (scale - 1) * ch / 2);
    return {
      x: Math.max(-maxX, Math.min(maxX, newPan.x)),
      y: Math.max(-maxY, Math.min(maxY, newPan.y)),
    };
  }, [mapImages]);
  const [dragging, setDragging] = useState(false);
  const [mapFocused, setMapFocused] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [hoveredAsset, setHoveredAsset] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [simulatedPositions, setSimulatedPositions] = useState({});
  const dragStart = useRef(null);
  const containerRef = useRef(null);
  const imageRef = useRef(null);

  const handleZoomIn = () => {
    const newZoom = Math.min(zoom + 10, 300);
    const newScale = 1 + (newZoom / 100) * 3;
    setZoom(newZoom);
    setZoomInput(newZoom.toString());
    setPan(prev => clampPan(prev, newScale));
  };

  const handleZoomOut = () => {
    const newZoom = Math.max(zoom - 10, 0);
    const newScale = 1 + (newZoom / 100) * 3;
    setZoom(newZoom);
    setZoomInput(newZoom.toString());
    setPan(prev => clampPan(prev, newScale));
  };

  const handleReset = () => {
    setZoom(0);
    setZoomInput('0');
    setPan({ x: 0, y: 0 });
  };

  const handleZoomChange = (value) => {
    const numValue = Math.max(0, Math.min(300, parseInt(value) || 0));
    const newScale = 1 + (numValue / 100) * 3;
    setZoom(numValue);
    setZoomInput(numValue.toString());
    setPan(prev => clampPan(prev, newScale));
  };

  const actualScale = 1 + (zoom / 100) * 3;

  const handleWheel = useCallback((e) => {
    if (!mapFocused) return;
    e.preventDefault();
    const delta = e.deltaY > 0 ? -10 : 10;
    const newZoom = Math.max(0, Math.min(300, zoom + delta));
    const newScale = 1 + (newZoom / 100) * 3;
    setZoom(newZoom);
    setZoomInput(newZoom.toString());
    setPan(prev => clampPan(prev, newScale));
  }, [zoom, clampPan, mapFocused]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  const handleMouseDown = (e) => {
    setDragging(true);
    dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e) => {
    if (!dragging || !dragStart.current) return;
    setPan(clampPan({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y }, actualScale));
  };

  const handleMouseUp = () => { setDragging(false); dragStart.current = null; };

  const handleTouchStart = (e) => {
    if (e.touches.length === 1) {
      setDragging(true);
      dragStart.current = { x: e.touches[0].clientX - pan.x, y: e.touches[0].clientY - pan.y };
    }
  };

  const handleTouchMove = (e) => {
    if (!dragging || !dragStart.current || e.touches.length !== 1) return;
    setPan(clampPan({ x: e.touches[0].clientX - dragStart.current.x, y: e.touches[0].clientY - dragStart.current.y }, actualScale));
  };

  const handleMouseMoveTrack = (e) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    }
  };

  useEffect(() => {
    if (!simulating) return;

    const interval = setInterval(() => {
      setSimulatedPositions(prev => {
        const newPos = { ...prev };
        assets.forEach(asset => {
          if (!newPos[asset.id]) {
            newPos[asset.id] = getAssetPosition(asset);
          }
          if (Math.random() > 0.7) {
            const dept = Object.values(DEPARTMENT_LAYOUT)[Math.floor(Math.random() * Object.keys(DEPARTMENT_LAYOUT).length)];
            newPos[asset.id] = {
              x: dept.x + dept.w * Math.random(),
              y: dept.y + dept.h * Math.random(),
            };
          }
        });
        return newPos;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [simulating, assets]);

  if (isLoading) return <Skeleton className="w-full h-[500px] rounded-xl" />;

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div>
          <h3 className="text-sm font-semibold text-foreground">{floorLabel || `Floor ${floor}`}</h3>
          <span className="text-xs text-muted-foreground">{assets.length} assets on this floor</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleZoomOut} title="Zoom out">
              <ZoomOut className="w-4 h-4" />
            </Button>
            <input
              type="number"
              min="0"
              max="300"
              value={zoomInput}
              onChange={(e) => setZoomInput(e.target.value)}
              onBlur={(e) => handleZoomChange(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleZoomChange(e.target.value)}
              className="w-16 h-7 text-xs text-center border border-border rounded bg-card focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <span className="text-xs text-muted-foreground">%</span>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleZoomIn} title="Zoom in">
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 ml-1" onClick={handleReset} title="Reset view">
              <Maximize2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div
        ref={containerRef}
        className="relative overflow-hidden bg-muted/30"
        style={{ height: '520px', cursor: dragging ? 'grabbing' : (mapFocused ? 'grab' : 'default') }}
        onClick={() => setMapFocused(true)}
        onMouseDown={handleMouseDown}
        onMouseMove={(e) => { handleMouseMove(e); handleMouseMoveTrack(e); }}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => { handleMouseUp(); setHoveredAsset(null); setMapFocused(false); }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
      >
        <div
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${actualScale})`,
            transformOrigin: 'center center',
            width: '100%',
            height: '100%',
            transition: dragging ? 'none' : 'transform 0.2s ease',
          }}
        >
          {(!mapImages || mapImages.length === 0) ? (
            <div className="w-full h-full flex items-center justify-center bg-muted/20">
              <div className="text-center p-8">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                  <svg className="w-10 h-10 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Map Required</h3>
                <p className="text-sm text-muted-foreground">Please upload floor map images in the Admin panel</p>
              </div>
            </div>
          ) : (
            <div className="relative w-full h-full flex items-center justify-center">
              {mapImages.map((img, idx) => (
                <img
                  key={idx}
                  ref={idx === 0 ? imageRef : null}
                  src={img.url}
                  alt={`Floor ${floor} map ${idx + 1}`}
                  style={{
                    position: 'absolute',
                    left: `${img.x}%`,
                    top: `${img.y}%`,
                    width: `${img.width}%`,
                    height: `${img.height}%`,
                    objectFit: 'contain',
                  }}
                  className="select-none"
                  draggable={false}
                />
              ))}
              {imageRef.current && assets.map(asset => {
                const pos = simulating && simulatedPositions[asset.id] ? simulatedPositions[asset.id] : getAssetPosition(asset);
                const isSelected = selectedAsset?.id === asset.id;
                const isHighlighted = highlightAssetId && asset.asset_id === highlightAssetId;
                const isMissing = asset.status === 'missing';
                const color = STATUS_COLOR[asset.status] || '#6b7280';

                const imgRect = imageRef.current.getBoundingClientRect();
                const containerRect = imageRef.current.parentElement.getBoundingClientRect();
                const imgLeft = (containerRect.width - imgRect.width) / 2;
                const imgTop = (containerRect.height - imgRect.height) / 2;

                return (
                  <div
                    key={asset.id}
                    onClick={(e) => { e.stopPropagation(); onSelectAsset(asset); }}
                    onMouseEnter={() => setHoveredAsset(asset)}
                    onMouseLeave={() => setHoveredAsset(null)}
                    style={{
                      left: `calc(${imgLeft}px + ${pos.x}% * ${imgRect.width} / 100)`,
                      top: `calc(${imgTop}px + ${pos.y}% * ${imgRect.height} / 100)`,
                      position: 'absolute',
                      transform: 'translate(-50%, -50%)',
                      transition: simulating ? 'left 2s ease-in-out, top 2s ease-in-out' : 'none'
                    }}
                    className="cursor-pointer group"
                  >
                    {(isSelected || isHighlighted) && !isMissing && (
                      <div
                        className="absolute rounded-full animate-ping opacity-60"
                        style={{ background: color, width: 20, height: 20, top: -4, left: -4 }}
                      />
                    )}
                    {isMissing ? (
                      <div
                        className="rounded-full border-2 border-dashed opacity-80"
                        style={{ borderColor: '#ef4444', width: 12, height: 12 }}
                      />
                    ) : (
                      <div
                        className="w-3 h-3 rounded-full border-2 border-white shadow-md"
                        style={{ background: color }}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {hoveredAsset && mapImages?.length > 0 && (
        <div style={{
          position: 'fixed',
          left: mousePos.x + 15,
          top: mousePos.y + 15,
          pointerEvents: 'none',
          zIndex: 10000
        }}>
          <AssetTooltip asset={hoveredAsset} zoom={actualScale} />
        </div>
      )}

      <div className="flex flex-wrap gap-4 px-4 py-3 border-t border-border">
        {[
          { label: 'Available', color: '#10b981' },
          { label: 'In Use', color: '#3b82f6' },
          { label: 'Maintenance', color: '#f59e0b' },
          { label: 'Missing', color: null, dashed: true },
        ].map(item => (
          <div key={item.label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            {item.dashed ? (
              <span className="w-3 h-3 rounded-full border-2 border-dashed inline-block" style={{ borderColor: '#ef4444' }} />
            ) : (
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />
            )}
            {item.label}
          </div>
        ))}
        <span className="text-xs text-muted-foreground ml-auto">Scroll to zoom (0-300%) · Drag to pan</span>
      </div>
    </div>
  );
}