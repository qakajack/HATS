import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { AlertTriangle } from 'lucide-react';

export default function ReportBrokenDialog({ asset, open, onClose, onSuccess }) {
  const [form, setForm] = useState({ name: '', staff_id: '', reason: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    // 1. Set asset status to maintenance
    await base44.entities.Asset.update(asset.id, { status: 'maintenance' });

    // 2. Create an alert for the admin
    await base44.entities.Alert.create({
      asset_id: asset.asset_id,
      asset_name: asset.asset_name,
      alert_type: 'maintenance_flagged',
      severity: 'high',
      status: 'active',
      message: `Asset reported broken by ${form.name} (ID: ${form.staff_id}). Reason: ${form.reason}`,
    });

    setSubmitting(false);
    onSuccess();
    onClose();
  };

  const handleChange = (field) => (e) => setForm(f => ({ ...f, [field]: e.target.value }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-destructive" />
            </div>
            <DialogTitle>Report Asset as Broken</DialogTitle>
          </div>
          <DialogDescription>
            Reporting <span className="font-semibold text-foreground">{asset?.asset_name}</span>. This will set its status to <span className="font-semibold text-amber-600">Maintenance</span> and alert the admin.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label htmlFor="rep-name">Your Name</Label>
            <Input id="rep-name" placeholder="e.g. Jane Smith" value={form.name} onChange={handleChange('name')} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rep-id">Staff ID</Label>
            <Input id="rep-id" placeholder="e.g. EMP-1042" value={form.staff_id} onChange={handleChange('staff_id')} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="rep-reason">Reason / Description</Label>
            <Textarea id="rep-reason" placeholder="Describe what is wrong with the asset..." rows={3} value={form.reason} onChange={handleChange('reason')} required />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="outline" onClick={onClose} disabled={submitting}>Cancel</Button>
            <Button type="submit" variant="destructive" disabled={submitting}>
              {submitting ? 'Submitting...' : 'Report Broken'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}