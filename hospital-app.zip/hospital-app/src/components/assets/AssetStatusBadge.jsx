import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const statusConfig = {
  available: { label: 'Available', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  maintenance: { label: 'Maintenance', className: 'bg-amber-100 text-amber-700 border-amber-200' },
  decommissioned: { label: 'Decommissioned', className: 'bg-gray-100 text-gray-600 border-gray-200' },
  missing: { label: 'Missing', className: 'bg-red-100 text-red-700 border-red-200' },
};

export default function AssetStatusBadge({ status }) {
  const config = statusConfig[status] || statusConfig.available;
  return (
    <Badge variant="outline" className={cn('text-[11px] font-medium border', config.className)}>
      {config.label}
    </Badge>
  );
}