import React from 'react';
import { Syringe, Monitor, Accessibility, Wind, Heart, Scan, Radiation, BedDouble, MoveHorizontal, Package } from 'lucide-react';

const icons = {
  infusion_pump: Syringe,
  patient_monitor: Monitor,
  wheelchair: Accessibility,
  ventilator: Wind,
  defibrillator: Heart,
  ultrasound: Scan,
  portable_xray: Radiation,
  bed: BedDouble,
  stretcher: MoveHorizontal,
  other: Package,
};

export default function EquipmentIcon({ type, className = 'w-4 h-4' }) {
  const Icon = icons[type] || Package;
  return <Icon className={className} />;
}