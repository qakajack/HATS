import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Pencil, Trash2, MapPin } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow } from 'date-fns';
import AssetStatusBadge from './AssetStatusBadge';
import EquipmentIcon from './EquipmentIcon';
import { Link, useNavigate } from 'react-router-dom';

const DEPT_LABELS = {
  emergency: 'Emergency', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardiology', pediatrics: 'Pediatrics', oncology: 'Oncology',
  neurology: 'Neurology', orthopedics: 'Orthopedics', general_ward: 'General Ward',
  outpatient: 'Outpatient', storage: 'Storage',
};

const TYPE_LABELS = {
  infusion_pump: 'Infusion Pump', patient_monitor: 'Patient Monitor', wheelchair: 'Wheelchair',
  ventilator: 'Ventilator', defibrillator: 'Defibrillator', ultrasound: 'Ultrasound',
  portable_xray: 'Portable X-Ray', bed: 'Bed', stretcher: 'Stretcher', other: 'Other',
};

export default function AssetTable({ assets, isLoading, onEdit, onDelete, readOnly = false }) {
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-4 space-y-3">
          {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
        </div>
      </div>
    );
  }

  if (assets.length === 0) {
    return (
      <div className="bg-card rounded-xl border border-border p-12 text-center">
        <p className="text-muted-foreground">No assets found matching your filters.</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Asset</TableHead>
              <TableHead className="font-semibold">ID</TableHead>
              <TableHead className="font-semibold">Type</TableHead>
              <TableHead className="font-semibold">Department</TableHead>
              <TableHead className="font-semibold">Floor</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold">Battery</TableHead>
              <TableHead className="font-semibold">Last Movement</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assets.map(asset => (
              <TableRow key={asset.id} className="hover:bg-muted/30 transition-colors">
                <TableCell>
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <EquipmentIcon type={asset.equipment_type} className="w-4 h-4 text-primary" />
                    </div>
                    <span className="font-medium text-sm">{asset.asset_name}</span>
                  </div>
                </TableCell>
                <TableCell className="text-xs font-mono text-muted-foreground">{asset.asset_id}</TableCell>
                <TableCell className="text-sm">{TYPE_LABELS[asset.equipment_type] || asset.equipment_type}</TableCell>
                <TableCell className="text-sm">{DEPT_LABELS[asset.department] || asset.department || '—'}</TableCell>
                <TableCell className="text-sm">{asset.floor || '—'}</TableCell>
                <TableCell><AssetStatusBadge status={asset.status} /></TableCell>
                <TableCell>
                  {asset.battery_level != null ? (
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${asset.battery_level > 50 ? 'bg-emerald-500' : asset.battery_level > 20 ? 'bg-amber-500' : 'bg-red-500'}`}
                          style={{ width: `${asset.battery_level}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">{asset.battery_level}%</span>
                    </div>
                  ) : <span className="text-xs text-muted-foreground">—</span>}
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {asset.last_seen
                    ? formatDistanceToNow(new Date(asset.last_seen), { addSuffix: true })
                    : '—'}
                </TableCell>
                <TableCell>
                  {readOnly ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 gap-1.5 text-xs text-muted-foreground hover:text-foreground"
                      onClick={() => navigate(`/FloorMap?asset=${asset.asset_id}&floor=${asset.floor || '1'}`)}
                    >
                      <MapPin className="w-3.5 h-3.5" /> Locate
                    </Button>
                  ) : (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(asset)}>
                          <Pencil className="w-3.5 h-3.5 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => navigate(`/FloorMap?asset=${asset.asset_id}&floor=${asset.floor || '1'}`)}>
                          <MapPin className="w-3.5 h-3.5 mr-2" /> Locate
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" onClick={() => onDelete(asset.id)}>
                          <Trash2 className="w-3.5 h-3.5 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}