import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AssetTable from '../assets/AssetTable';
import AssetFormDialog from '../assets/AssetFormDialog';

const STATUSES = [
  { value: 'all', label: 'All Statuses' },
  { value: 'available', label: 'Available' },
  { value: 'in_use', label: 'In Use' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'decommissioned', label: 'Decommissioned' },
  { value: 'missing', label: 'Missing' },
];

const TYPES = [
  { value: 'all', label: 'All Types' },
  { value: 'infusion_pump', label: 'Infusion Pump' },
  { value: 'patient_monitor', label: 'Patient Monitor' },
  { value: 'wheelchair', label: 'Wheelchair' },
  { value: 'ventilator', label: 'Ventilator' },
  { value: 'defibrillator', label: 'Defibrillator' },
  { value: 'ultrasound', label: 'Ultrasound' },
  { value: 'portable_xray', label: 'Portable X-Ray' },
  { value: 'bed', label: 'Bed' },
  { value: 'stretcher', label: 'Stretcher' },
  { value: 'other', label: 'Other' },
];

export default function AdminAssets() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState(null);
  const queryClient = useQueryClient();

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Asset.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['assets'] }); setFormOpen(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Asset.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['assets'] }); setFormOpen(false); setEditingAsset(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Asset.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['assets'] }),
  });

  const filteredAssets = useMemo(() => assets.filter(a => {
    const matchSearch = !search ||
      a.asset_name?.toLowerCase().includes(search.toLowerCase()) ||
      a.asset_id?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    const matchType = typeFilter === 'all' || a.equipment_type === typeFilter;
    return matchSearch && matchStatus && matchType;
  }), [assets, search, statusFilter, typeFilter]);

  const handleEdit = (asset) => { setEditingAsset(asset); setFormOpen(true); };
  const handleSubmit = (data) => {
    if (editingAsset) updateMutation.mutate({ id: editingAsset.id, data });
    else createMutation.mutate(data);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search assets..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-card" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[150px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>{TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>{STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
        </Select>
        <Button onClick={() => { setEditingAsset(null); setFormOpen(true); }} className="gap-2 ml-auto">
          <Plus className="w-4 h-4" /> Add Asset
        </Button>
      </div>

      <AssetTable
        assets={filteredAssets}
        isLoading={isLoading}
        onEdit={handleEdit}
        onDelete={(id) => deleteMutation.mutate(id)}
      />

      <AssetFormDialog
        open={formOpen}
        onOpenChange={(open) => { setFormOpen(open); if (!open) setEditingAsset(null); }}
        asset={editingAsset}
        onSubmit={handleSubmit}
        isSubmitting={createMutation.isPending || updateMutation.isPending}
      />
    </div>
  );
}