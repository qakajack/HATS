import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Upload, Layers, ImageIcon, CheckCircle2, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useFloorConfig } from '../../hooks/useFloorConfig';
import FloorImageManager from './FloorImageManager';

export default function AdminFloorMaps() {
  const { floorConfig, saveConfig } = useFloorConfig();
  const [uploading, setUploading] = useState(null);
  const [newFloorName, setNewFloorName] = useState('');
  const [managingFloor, setManagingFloor] = useState(null);

  const handleAddFloor = async () => {
    const name = newFloorName.trim();
    if (!name || floorConfig.find(f => f.id === name)) return;

    // Prompt for file upload
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      setUploading(name);
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      saveConfig([...floorConfig, { id: name, label: `Floor ${name}`, mapUrl: file_url }]);
      setNewFloorName('');
      setUploading(null);
    };
    input.click();
  };

  const handleRemoveFloor = (id) => {
    saveConfig(floorConfig.filter(f => f.id !== id));
  };

  const handleLabelChange = (id, label) => {
    saveConfig(floorConfig.map(f => f.id === id ? { ...f, label } : f));
  };

  const handleUploadMap = async (id, files) => {
    setUploading(id);
    const urls = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push({ url: file_url, x: 0, y: 0, width: 100, height: 100 });
    }
    const floor = floorConfig.find(f => f.id === id);
    const existing = floor?.mapImages || [];
    saveConfig(floorConfig.map(f => f.id === id ? { ...f, mapImages: [...existing, ...urls] } : f));
    setUploading(null);
  };

  const handleRemoveImage = (floorId, imageIndex) => {
    saveConfig(floorConfig.map(f => {
      if (f.id === floorId) {
        const newImages = [...(f.mapImages || [])];
        newImages.splice(imageIndex, 1);
        return { ...f, mapImages: newImages };
      }
      return f;
    }));
  };

  const handleUpdateImagePosition = (floorId, imageIndex, updates) => {
    saveConfig(floorConfig.map(f => {
      if (f.id === floorId) {
        const newImages = [...(f.mapImages || [])];
        newImages[imageIndex] = { ...newImages[imageIndex], ...updates };
        return { ...f, mapImages: newImages };
      }
      return f;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold text-foreground mb-1 flex items-center gap-2">
          <Layers className="w-4 h-4 text-primary" /> Floor Configuration
        </h3>
        <p className="text-xs text-muted-foreground mb-5">Add, remove, and rename hospital floors. Upload floor map images for each level.</p>

        <div className="space-y-3">
          {floorConfig.map(floor => (
            <div key={floor.id} className="flex items-center gap-3 p-4 rounded-lg border border-border bg-muted/30">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary text-sm">
                {floor.id}
              </div>

              <div className="flex-1 min-w-0">
                <Input
                  value={floor.label}
                  onChange={e => handleLabelChange(floor.id, e.target.value)}
                  className="h-8 text-sm bg-card max-w-[200px]"
                />
              </div>

              {/* Map upload status */}
              <div className="flex items-center gap-2">
                {(floor.mapImages?.length || 0) > 0 ? (
                  <Badge className="bg-emerald-100 text-emerald-700 gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {floor.mapImages.length} image{floor.mapImages.length > 1 ? 's' : ''}
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground gap-1">
                    <ImageIcon className="w-3 h-3" /> No images
                  </Badge>
                )}
              </div>

              {/* Upload & Manage buttons */}
              <label className={cn("cursor-pointer", uploading === floor.id && "opacity-50 pointer-events-none")}>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/jpg"
                  multiple
                  className="hidden"
                  onChange={e => e.target.files.length > 0 && handleUploadMap(floor.id, Array.from(e.target.files))}
                />
                <Button size="sm" variant="outline" className="gap-1.5 text-xs pointer-events-none" asChild>
                  <span>
                    {uploading === floor.id
                      ? <><div className="w-3 h-3 border-2 border-muted border-t-primary rounded-full animate-spin" /> Uploading...</>
                      : <><Upload className="w-3 h-3" /> Add Images</>
                    }
                  </span>
                </Button>
              </label>

              {(floor.mapImages?.length || 0) > 0 && (
                <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={() => setManagingFloor(floor)}>
                  <Settings className="w-3 h-3" /> Manage Layout
                </Button>
              )}

              <Button size="icon" variant="ghost" className="text-destructive hover:text-destructive h-8 w-8 shrink-0"
                onClick={() => handleRemoveFloor(floor.id)}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>

        {/* Add new floor */}
        <div className="flex items-center gap-3 mt-4 pt-4 border-t border-border">
          <Input
            placeholder="Floor ID (e.g. 6, R1, Roof)"
            value={newFloorName}
            onChange={e => setNewFloorName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleAddFloor()}
            className="max-w-[200px] bg-card"
          />
          <Button onClick={handleAddFloor} disabled={!newFloorName.trim() || uploading} className="gap-2">
            {uploading ? (
              <><div className="w-3 h-3 border-2 border-muted border-t-primary rounded-full animate-spin" /> Creating...</>
            ) : (
              <><Plus className="w-4 h-4" /> Add Floor (with image)</>
            )}
          </Button>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800">
        <strong>Note:</strong> You can upload multiple JPEG/PNG images per floor. Use "Manage Layout" to position and resize each image to fit together properly.
      </div>

      {managingFloor && (
        <FloorImageManager
          floor={managingFloor}
          onClose={() => setManagingFloor(null)}
          onUpdate={handleUpdateImagePosition}
          onRemove={handleRemoveImage}
        />
      )}
    </div>
  );
}