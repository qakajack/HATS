import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Upload, Info, CheckCircle2, AlertTriangle, Wifi, ChevronRight } from 'lucide-react';

const STEPS = [
  {
    n: 1,
    title: 'Log into Cisco DNA Spaces',
    desc: 'Go to your Cisco DNA Spaces dashboard (dnaspaces.cisco.com) and sign in as an admin.',
  },
  {
    n: 2,
    title: 'Create a Firehose Connector',
    desc: 'Navigate to Act → Firehose → Add New. Select "Asset Location Updates" as the data stream type.',
  },
  {
    n: 3,
    title: 'Set the Webhook URL',
    desc: 'Paste your app\'s webhook endpoint as the destination URL. Live webhook ingestion requires a backend (Builder+ plan). For now, use the manual import below.',
  },
  {
    n: 4,
    title: 'Map BLE Tag IDs',
    desc: 'Ensure your asset BLE Tag IDs in this app (Assets page → ble_tag_id field) match the MAC addresses registered in Cisco DNA Spaces.',
  },
  {
    n: 5,
    title: 'Export & Import Location Data',
    desc: 'Export a location snapshot from Cisco DNA Spaces (CSV or JSON) and import it below to update asset positions.',
  },
];

// Expected Cisco DNA Spaces export format:
// [{ "macAddress": "aa:bb:cc:dd:ee:ff", "mapHierarchy": "floor/zone", "x": 12.5, "y": 34.2, "timestamp": "..." }]

export default function AdminCiscoIntegration() {
  const queryClient = useQueryClient();
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState(null);

  const handleFileImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImporting(true);
    setResult(null);

    const text = await file.text();
    let records = [];
    try {
      const parsed = JSON.parse(text);
      records = Array.isArray(parsed) ? parsed : parsed.locations || parsed.assets || [];
    } catch {
      // Try CSV
      const lines = text.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/[^a-z]/g, '_'));
      records = lines.slice(1).map(line => {
        const vals = line.split(',');
        const obj = {};
        headers.forEach((h, i) => { obj[h] = vals[i]?.trim(); });
        return obj;
      });
    }

    // Fetch current assets to match by ble_tag_id
    const assets = await base44.entities.Asset.list('-updated_date', 500);
    const tagMap = {};
    assets.forEach(a => { if (a.ble_tag_id) tagMap[a.ble_tag_id.toLowerCase()] = a; });

    let updated = 0, skipped = 0;
    for (const rec of records) {
      const mac = (rec.macAddress || rec.mac_address || rec.ble_tag_id || rec.tag_id || '').toLowerCase();
      const asset = tagMap[mac];
      if (!asset) { skipped++; continue; }

      // Extract floor/dept from mapHierarchy e.g. "Hospital > Floor 2 > ICU"
      const hierarchy = rec.mapHierarchy || rec.map_hierarchy || rec.location || '';
      const floorMatch = hierarchy.match(/floor\s*(\w+)/i);
      const floor = floorMatch ? floorMatch[1] : asset.floor;

      const zone = rec.zone || rec.floorName || rec.floor_name || asset.zone;
      const last_seen = rec.timestamp || rec.lastSeen || rec.last_seen || new Date().toISOString();

      await base44.entities.Asset.update(asset.id, { floor, zone, last_seen });

      // Log to location history
      await base44.entities.LocationHistory.create({
        asset_id: asset.asset_id,
        floor,
        department: asset.department,
        zone,
        signal_strength: rec.rssi ? parseFloat(rec.rssi) : null,
        detected_by: 'Cisco DNA Spaces Import',
        timestamp: last_seen,
      });

      updated++;
    }

    queryClient.invalidateQueries({ queryKey: ['assets'] });
    setResult({ updated, skipped, total: records.length });
    setImporting(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-card rounded-xl border border-border p-5">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-9 h-9 rounded-lg bg-blue-100 flex items-center justify-center">
            <Wifi className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-foreground">Cisco DNA Spaces Integration</h3>
            <p className="text-xs text-muted-foreground">Push BLE/Wi-Fi asset location data into HATS</p>
          </div>
          <Badge className="ml-auto bg-blue-100 text-blue-700">BLE Tracking</Badge>
        </div>
      </div>

      {/* Setup Steps */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h4 className="text-sm font-semibold text-foreground mb-4">Setup Guide</h4>
        <div className="space-y-3">
          {STEPS.map((step) => (
            <div key={step.n} className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                {step.n}
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{step.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Webhook note */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-800">
          <strong>Live Webhook Ingestion</strong> (real-time push from Cisco DNA Spaces) requires a backend endpoint, available on the <strong>Builder+</strong> plan. Until then, use the manual import below to sync location snapshots.
        </div>
      </div>

      {/* Manual Import */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h4 className="text-sm font-semibold text-foreground mb-1">Manual Location Import</h4>
        <p className="text-xs text-muted-foreground mb-4">
          Export a location snapshot from Cisco DNA Spaces (JSON or CSV) and upload it here. Assets are matched by their <strong>BLE Tag ID</strong>. The expected JSON format is an array of objects with <code className="bg-muted px-1 rounded text-xs">macAddress</code>, <code className="bg-muted px-1 rounded text-xs">mapHierarchy</code>, and <code className="bg-muted px-1 rounded text-xs">timestamp</code>.
        </p>

        <label className={importing ? 'opacity-50 pointer-events-none' : ''}>
          <input type="file" accept=".json,.csv" className="hidden" onChange={handleFileImport} />
          <Button variant="outline" className="gap-2 pointer-events-none" asChild>
            <span>
              {importing
                ? <><div className="w-4 h-4 border-2 border-muted border-t-primary rounded-full animate-spin" /> Processing...</>
                : <><Upload className="w-4 h-4" /> Upload Cisco Export (JSON / CSV)</>
              }
            </span>
          </Button>
        </label>

        {result && (
          <div className="mt-4 flex items-center gap-3 p-3 rounded-lg bg-emerald-50 border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <p className="text-sm text-emerald-800">
              Import complete — <strong>{result.updated}</strong> assets updated, <strong>{result.skipped}</strong> records skipped (no matching BLE Tag ID) out of <strong>{result.total}</strong> total.
            </p>
          </div>
        )}
      </div>

      {/* Field mapping reference */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
          <Info className="w-4 h-4 text-primary" /> BLE Tag ID Matching
        </h4>
        <p className="text-xs text-muted-foreground mb-3">
          For location updates to sync, each asset in HATS must have its <strong>BLE Tag ID</strong> set to match the MAC address registered in Cisco DNA Spaces.
        </p>
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="bg-muted/40 rounded-lg p-3 border border-border">
            <p className="font-semibold text-foreground mb-1">Cisco DNA Spaces field</p>
            <code className="text-primary">macAddress</code>
          </div>
          <div className="bg-muted/40 rounded-lg p-3 border border-border">
            <p className="font-semibold text-foreground mb-1">HATS Asset field</p>
            <code className="text-primary">ble_tag_id</code>
          </div>
        </div>
      </div>
    </div>
  );
}