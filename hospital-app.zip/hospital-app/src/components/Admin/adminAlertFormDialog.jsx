import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

const defaultForm = {
  asset_id: '', asset_name: '', alert_type: 'maintenance_due',
  severity: 'medium', message: '', status: 'active',
};

export default function AdminAlertFormDialog({ open, onOpenChange, onSubmit, isSubmitting }) {
  const [form, setForm] = useState(defaultForm);
  const update = (f, v) => setForm(p => ({ ...p, [f]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    setForm(defaultForm);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Create Alert</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Asset ID *</Label>
              <Input value={form.asset_id} onChange={e => update('asset_id', e.target.value)} required placeholder="AST-001" />
            </div>
            <div className="space-y-1.5">
              <Label>Asset Name *</Label>
              <Input value={form.asset_name} onChange={e => update('asset_name', e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label>Alert Type</Label>
              <Select value={form.alert_type} onValueChange={v => update('alert_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low_battery">Low Battery</SelectItem>
                  <SelectItem value="idle_too_long">Idle Too Long</SelectItem>
                  <SelectItem value="maintenance_due">Maintenance Due</SelectItem>
                  <SelectItem value="maintenance_flagged">Maintenance Flagged</SelectItem>
                  <SelectItem value="missing">Missing</SelectItem>
                  <SelectItem value="zone_breach">Zone Breach</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Severity</Label>
              <Select value={form.severity} onValueChange={v => update('severity', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Message *</Label>
            <Textarea value={form.message} onChange={e => update('message', e.target.value)} rows={3} required />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Creating...' : 'Create Alert'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}