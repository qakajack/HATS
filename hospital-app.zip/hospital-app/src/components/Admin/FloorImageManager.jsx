import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2 } from 'lucide-react';

export default function FloorImageManager({ floor, onClose, onUpdate, onRemove }) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const images = floor.mapImages || [];
  const currentImage = images[selectedIndex];

  if (!currentImage) return null;

  const handleUpdate = (field, value) => {
    onUpdate(floor.id, selectedIndex, { [field]: parseFloat(value) || 0 });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Floor Images - {floor.label}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Image selector */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedIndex(idx)}
                className={`relative shrink-0 w-24 h-24 rounded border-2 ${
                  selectedIndex === idx ? 'border-primary' : 'border-border'
                }`}
              >
                <img src={img.url} alt={`Image ${idx + 1}`} className="w-full h-full object-cover rounded" />
                <span className="absolute top-1 left-1 bg-black/60 text-white text-xs px-1.5 py-0.5 rounded">
                  {idx + 1}
                </span>
              </button>
            ))}
          </div>

          {/* Preview */}
          <div className="border rounded-lg p-4 bg-muted/30">
            <h4 className="text-sm font-semibold mb-2">Preview</h4>
            <div className="relative w-full h-[300px] border rounded bg-card overflow-hidden">
              {images.map((img, idx) => (
                <img
                  key={idx}
                  src={img.url}
                  alt={`Layer ${idx + 1}`}
                  style={{
                    position: 'absolute',
                    left: `${img.x}%`,
                    top: `${img.y}%`,
                    width: `${img.width}%`,
                    height: `${img.height}%`,
                    objectFit: 'contain',
                    opacity: selectedIndex === idx ? 1 : 0.6,
                    border: selectedIndex === idx ? '2px solid hsl(var(--primary))' : 'none',
                  }}
                />
              ))}
            </div>
          </div>

          {/* Position controls */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">X Position (%)</Label>
              <Input
                type="number"
                value={currentImage.x}
                onChange={e => handleUpdate('x', e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Y Position (%)</Label>
              <Input
                type="number"
                value={currentImage.y}
                onChange={e => handleUpdate('y', e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Width (%)</Label>
              <Input
                type="number"
                value={currentImage.width}
                onChange={e => handleUpdate('width', e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Height (%)</Label>
              <Input
                type="number"
                value={currentImage.height}
                onChange={e => handleUpdate('height', e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between pt-4 border-t">
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                onRemove(floor.id, selectedIndex);
                if (selectedIndex >= images.length - 1) setSelectedIndex(Math.max(0, selectedIndex - 1));
              }}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" /> Remove Image {selectedIndex + 1}
            </Button>
            <Button onClick={onClose}>Done</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}