import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import MaintenanceList from '../maintenance/MaintenanceList';
import MaintenanceFormDialog from '../maintenance/MaintenanceFormDialog';

export default function AdminMaintenance() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['maintenance-requests'],
    queryFn: () => base44.entities.MaintenanceRequest.list('-created_date', 200),
  });

  const { data: assets = [] } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MaintenanceRequest.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['maintenance-requests'] }); setFormOpen(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MaintenanceRequest.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['maintenance-requests'] }),
  });

  const filtered = statusFilter === 'all' ? requests : requests.filter(r => r.status === statusFilter);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-sm text-muted-foreground">{requests.filter(r => r.status === 'open').length} open requests</p>
        <Button onClick={() => setFormOpen(true)} className="gap-2 ml-auto">
          <Plus className="w-4 h-4" /> New Request
        </Button>
      </div>

      <MaintenanceList
        requests={filtered}
        isLoading={isLoading}
        onUpdateStatus={(id, status) =>
          updateMutation.mutate({ id, data: { status, ...(status === 'completed' ? { completed_at: new Date().toISOString() } : {}) } })
        }
      />

      <MaintenanceFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        assets={assets}
        onSubmit={(data) => createMutation.mutate(data)}
        isSubmitting={createMutation.isPending}
      />
    </div>
  );
}