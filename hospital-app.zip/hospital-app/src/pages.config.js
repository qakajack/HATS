import Admin from './pages/Admin';
import Alerts from './pages/Alerts';
import Assets from './pages/Assets';
import Dashboard from './pages/Dashboard';
import FloorMap from './pages/FloorMap';
import Maintenance from './pages/Maintenance';
import Reports from './pages/Reports';
import AdminLogin from './pages/AdminLogin';


export const PAGES = {
    "Admin": Admin,
    "Alerts": Alerts,
    "Assets": Assets,
    "Dashboard": Dashboard,
    "FloorMap": FloorMap,
    "Maintenance": Maintenance,
    "Reports": Reports,
    "AdminLogin": AdminLogin,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
};