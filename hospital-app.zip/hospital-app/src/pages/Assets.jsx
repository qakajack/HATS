import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '../components/layout/PageHeader';
import AssetTable from '../components/assets/AssetTable';

const EQUIPMENT_TYPES = [
  { value: 'all', label: 'All Types' },
  { value: 'infusion_pump', label: 'Infusion Pump' },
  { value: 'patient_monitor', label: 'Patient Monitor' },
  { value: 'wheelchair', label: 'Wheelchair' },
  { value: 'ventilator', label: 'Ventilator' },
  { value: 'defibrillator', label: 'Defibrillator' },
  { value: 'ultrasound', label: 'Ultrasound' },
  { value: 'portable_xray', label: 'Portable X-Ray' },
  { value: 'bed', label: 'Bed' },
  { value: 'stretcher', label: 'Stretcher' },
  { value: 'other', label: 'Other' },
];

const DEPARTMENTS = [
  { value: 'all', label: 'All Departments' },
  { value: 'emergency', label: 'Emergency' },
  { value: 'icu', label: 'ICU' },
  { value: 'surgery', label: 'Surgery' },
  { value: 'radiology', label: 'Radiology' },
  { value: 'cardiology', label: 'Cardiology' },
  { value: 'pediatrics', label: 'Pediatrics' },
  { value: 'oncology', label: 'Oncology' },
  { value: 'neurology', label: 'Neurology' },
  { value: 'orthopedics', label: 'Orthopedics' },
  { value: 'general_ward', label: 'General Ward' },
  { value: 'outpatient', label: 'Outpatient' },
  { value: 'storage', label: 'Storage' },
];

const STATUSES = [
  { value: 'all', label: 'All Statuses' },
  { value: 'available', label: 'Available' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'decommissioned', label: 'Decommissioned' },
  { value: 'missing', label: 'Missing' },
];

export default function Assets() {
  const urlParams = new URLSearchParams(window.location.search);
  const initialSearch = urlParams.get('search') || '';

  const [search, setSearch] = useState(initialSearch);
  const [typeFilter, setTypeFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState(urlParams.get('status') || 'all');

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const filteredAssets = useMemo(() => {
    return assets.filter(a => {
      const matchSearch = !search ||
        a.asset_name?.toLowerCase().includes(search.toLowerCase()) ||
        a.asset_id?.toLowerCase().includes(search.toLowerCase()) ||
        a.ble_tag_id?.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === 'all' || a.equipment_type === typeFilter;
      const matchDept = deptFilter === 'all' || a.department === deptFilter;
      const matchStatus = statusFilter === 'all' || a.status === statusFilter;
      return matchSearch && matchType && matchDept && matchStatus;
    });
  }, [assets, search, typeFilter, deptFilter, statusFilter]);

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Asset Inventory" subtitle={`${assets.length} registered assets`} />

      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, ID, or BLE tag..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 bg-card"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[160px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            {EQUIPMENT_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="w-[170px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            {DEPARTMENTS.map(d => <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] bg-card"><SelectValue /></SelectTrigger>
          <SelectContent>
            {STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <AssetTable
        assets={filteredAssets}
        isLoading={isLoading}
        readOnly
      />
    </div>
  );
}