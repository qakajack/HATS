import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { AlertTriangle, Battery, Clock, Wrench, HelpCircle, ShieldAlert, CheckCircle2, Eye } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';

const alertIcons = {
  low_battery: Battery,
  idle_too_long: Clock,
  maintenance_due: Wrench,
  maintenance_flagged: Wrench,
  missing: HelpCircle,
  zone_breach: ShieldAlert,
};

const severityStyles = {
  low: 'bg-secondary text-secondary-foreground',
  medium: 'bg-amber-100 text-amber-800',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800',
};

const statusStyles = {
  active: 'bg-red-100 text-red-700',
  acknowledged: 'bg-amber-100 text-amber-700',
  resolved: 'bg-emerald-100 text-emerald-700',
};

export default function Alerts() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.list('-created_date', 200),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Alert.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['alerts'] }),
  });

  const filtered = useMemo(() => {
    return alerts.filter(a => {
      const matchStatus = statusFilter === 'all' || a.status === statusFilter;
      const matchSeverity = severityFilter === 'all' || a.severity === severityFilter;
      return matchStatus && matchSeverity;
    });
  }, [alerts, statusFilter, severityFilter]);

  const handleAcknowledge = (alert) => {
    updateMutation.mutate({ id: alert.id, data: { status: 'acknowledged' } });
  };

  const handleResolve = (alert) => {
    updateMutation.mutate({
      id: alert.id,
      data: { status: 'resolved', resolved_at: new Date().toISOString() },
    });
  };

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Alerts" subtitle={`${alerts.filter(a => a.status === 'active').length} active alerts`}>
        <div className="flex gap-3">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] bg-card"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="acknowledged">Acknowledged</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[140px] bg-card"><SelectValue placeholder="Severity" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </PageHeader>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-card rounded-xl border border-border p-12 text-center">
          <AlertTriangle className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No alerts matching your filters.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(alert => {
            const Icon = alertIcons[alert.alert_type] || AlertTriangle;
            return (
              <div key={alert.id} className="bg-card rounded-xl border border-border p-4 flex items-start gap-4 hover:shadow-sm transition-shadow">
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center shrink-0",
                  alert.severity === 'critical' ? 'bg-red-100' : alert.severity === 'high' ? 'bg-orange-100' : 'bg-amber-100'
                )}>
                  <Icon className={cn(
                    "w-5 h-5",
                    alert.severity === 'critical' ? 'text-red-600' : alert.severity === 'high' ? 'text-orange-600' : 'text-amber-600'
                  )} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm text-foreground">{alert.asset_name || alert.asset_id}</span>
                    <Badge className={cn('text-[10px]', severityStyles[alert.severity])}>{alert.severity}</Badge>
                    <Badge className={cn('text-[10px]', statusStyles[alert.status])}>{alert.status}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{alert.message}</p>
                  <p className="text-xs text-muted-foreground mt-1.5">
                    {alert.alert_type?.replace(/_/g, ' ')} · {format(new Date(alert.created_date), 'MMM d, yyyy h:mm a')}
                  </p>
                </div>
                {alert.status !== 'resolved' && (
                  <div className="flex gap-2 shrink-0">
                    {alert.status === 'active' && (
                      <Button size="sm" variant="outline" onClick={() => handleAcknowledge(alert)} className="gap-1.5 text-xs">
                        <Eye className="w-3.5 h-3.5" /> Acknowledge
                      </Button>
                    )}
                    <Button size="sm" onClick={() => handleResolve(alert)} className="gap-1.5 text-xs">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Resolve
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}