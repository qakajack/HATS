import React, { useState, useEffect } from 'react';
import { LogOut } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import PageHeader from '../components/layout/PageHeader';
import AdminAssets from '../components/admin/AdminAssets';
import AdminAlerts from '../components/admin/AdminAlerts';
import AdminMaintenance from '../components/admin/AdminMaintenance';
import AdminReports from '../components/admin/AdminReports';
import AdminFloorMaps from '../components/admin/AdminFloorMaps';
import AdminCiscoIntegration from '../components/admin/AdminCiscoIntegration';
import AdminLogin, { getAdminSession, clearAdminSession, ADMIN_SESSION_KEY } from './AdminLogin';

export default function Admin() {
  const [session, setSession] = useState(() => getAdminSession());

  useEffect(() => {
    const handler = () => setSession(getAdminSession());
    window.addEventListener('hats_admin_session_change', handler);
    return () => window.removeEventListener('hats_admin_session_change', handler);
  }, []);

  if (!session) {
    return <AdminLogin onSuccess={setSession} />;
  }

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader
        title="Admin Panel"
        subtitle={`Signed in as ${session.username}`}
      >
        <Button variant="outline" size="sm" className="gap-2" onClick={() => { clearAdminSession(); setSession(null); }}>
          <LogOut className="w-4 h-4" /> Sign Out
        </Button>
      </PageHeader>
      <Tabs defaultValue="assets">
        <TabsList className="mb-6 flex-wrap h-auto gap-1">
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="floormaps">Floor Maps</TabsTrigger>
          <TabsTrigger value="cisco">Cisco DNA Spaces</TabsTrigger>
        </TabsList>

        <TabsContent value="assets"><AdminAssets /></TabsContent>
        <TabsContent value="alerts"><AdminAlerts /></TabsContent>
        <TabsContent value="maintenance"><AdminMaintenance /></TabsContent>
        <TabsContent value="reports"><AdminReports /></TabsContent>
        <TabsContent value="floormaps"><AdminFloorMaps /></TabsContent>
        <TabsContent value="cisco"><AdminCiscoIntegration /></TabsContent>
      </Tabs>
    </div>
  );
}