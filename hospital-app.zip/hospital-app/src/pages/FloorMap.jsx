import React, { useState, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import FloorMapView from '../components/map/FloorMapView';
import AssetMapSidebar from '../components/map/AssetMapSidebar';
import { useFloorConfig } from '../hooks/useFloorConfig';

export default function FloorMap() {
  const urlParams = new URLSearchParams(window.location.search);
  const highlightAssetId = urlParams.get('asset') || '';

  const { floorConfig } = useFloorConfig();
  const [selectedFloor, setSelectedFloor] = useState(urlParams.get('floor') || '1');
  const [search, setSearch] = useState(highlightAssetId);
  const [selectedAsset, setSelectedAsset] = useState(null);

  const { data: assets = [], isLoading, refetch } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const currentFloorConfig = floorConfig.find(f => f.id === selectedFloor) || floorConfig[0];

  const floorAssets = useMemo(() => {
    return assets.filter(a => {
      const matchFloor = a.floor === selectedFloor;
      const matchSearch = !search ||
        a.asset_name?.toLowerCase().includes(search.toLowerCase()) ||
        a.asset_id?.toLowerCase().includes(search.toLowerCase());
      return matchFloor && matchSearch;
    });
  }, [assets, selectedFloor, search]);

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Floor Map" subtitle="Interactive asset location view">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search assets..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 w-48 bg-card"
            />
          </div>
          <Select value={selectedFloor} onValueChange={setSelectedFloor}>
            <SelectTrigger className="w-[130px] bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>
              {floorConfig.map(f => (
                <SelectItem key={f.id} value={f.id}>{f.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </PageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <FloorMapView
            assets={floorAssets}
            floor={selectedFloor}
            floorLabel={currentFloorConfig?.label}
            mapImages={currentFloorConfig?.mapImages || []}
            selectedAsset={selectedAsset}
            onSelectAsset={setSelectedAsset}
            highlightAssetId={highlightAssetId}
            isLoading={isLoading}
          />
        </div>
        <div>
          <AssetMapSidebar
            assets={floorAssets}
            selectedAsset={selectedAsset}
            onSelectAsset={setSelectedAsset}
            onAssetUpdated={() => { refetch(); setSelectedAsset(null); }}
          />
        </div>
      </div>
    </div>
  );
}