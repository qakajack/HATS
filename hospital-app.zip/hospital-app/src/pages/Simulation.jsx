import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import { useFloorConfig } from '../hooks/useFloorConfig';

const STATUS_COLOR = {
  available: '#10b981',
  in_use: '#3b82f6',
  maintenance: '#f59e0b',
  missing: '#ef4444',
};

const EQUIPMENT_ABBR = {
  infusion_pump: 'IP', patient_monitor: 'PM', wheelchair: 'WC',
  ventilator: 'VN', defibrillator: 'DF', ultrasound: 'US',
  portable_xray: 'XR', bed: 'BD', stretcher: 'ST', other: 'OT',
};

const EQUIPMENT_LABELS = {
  infusion_pump: 'Infusion Pump', patient_monitor: 'Patient Monitor', wheelchair: 'Wheelchair',
  ventilator: 'Ventilator', defibrillator: 'Defibrillator', ultrasound: 'Ultrasound',
  portable_xray: 'Portable X-Ray', bed: 'Bed', stretcher: 'Stretcher', other: 'Other',
};

const DEPT_LABELS = {
  emergency: 'Emergency', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardiology', pediatrics: 'Pediatrics', oncology: 'Oncology',
  neurology: 'Neurology', orthopedics: 'Orthopedics', general_ward: 'General Ward',
  outpatient: 'Outpatient', storage: 'Storage',
};

// ── Mesh / wall helpers ──────────────────────────────────────────────────────
// Pixel classification thresholds
const WALL_DARK_THRESHOLD = 160;   // avg RGB below this = wall line
const OUTSIDE_ALPHA_THRESHOLD = 40; // alpha below this = outside building

function getPixel(imageData, px, py, w, h) {
  if (px < 0 || py < 0 || px >= w || py >= h) return null;
  const i = (py * w + px) * 4;
  return {
    r: imageData.data[i],
    g: imageData.data[i + 1],
    b: imageData.data[i + 2],
    a: imageData.data[i + 3],
  };
}

// BFS flood-fill from all edges to mark pixels reachable without crossing a wall as 'outside'
function buildOutsideMask(imageData, w, h) {
  const mask = new Uint8Array(w * h); // 1 = outside
  const queue = [];

  const enqueue = (x, y) => {
    const idx = y * w + x;
    if (mask[idx]) return;
    const i = idx * 4;
    const avg = (imageData.data[i] + imageData.data[i+1] + imageData.data[i+2]) / 3;
    if (imageData.data[i+3] < OUTSIDE_ALPHA_THRESHOLD || avg >= WALL_DARK_THRESHOLD) {
      // Only flood through non-wall pixels from the border
      if (imageData.data[i+3] < OUTSIDE_ALPHA_THRESHOLD) {
        mask[idx] = 1;
        queue.push(x, y);
      }
    }
  };

  for (let x = 0; x < w; x++) { enqueue(x, 0); enqueue(x, h - 1); }
  for (let y = 0; y < h; y++) { enqueue(0, y); enqueue(w - 1, y); }

  // BFS — flood through transparent/outside pixels only
  let qi = 0;
  while (qi < queue.length) {
    const x = queue[qi++], y = queue[qi++];
    const neighbors = [[x-1,y],[x+1,y],[x,y-1],[x,y+1]];
    for (const [nx, ny] of neighbors) {
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
      const nidx = ny * w + nx;
      if (mask[nidx]) continue;
      const ni = nidx * 4;
      const avg = (imageData.data[ni] + imageData.data[ni+1] + imageData.data[ni+2]) / 3;
      // Flood through transparent OR bright (non-wall) pixels that are outside the building
      if (imageData.data[ni+3] < OUTSIDE_ALPHA_THRESHOLD) {
        mask[nidx] = 1;
        queue.push(nx, ny);
      }
    }
  }
  return mask;
}

// Returns 'outside' | 'wall' | 'floor'
function classifyPixel(px, py, imageData, w, h, outsideMask) {
  if (px < 0 || py < 0 || px >= w || py >= h) return 'outside';
  const idx = py * w + px;
  if (outsideMask && outsideMask[idx]) return 'outside';
  const i = idx * 4;
  if (imageData.data[i+3] < OUTSIDE_ALPHA_THRESHOLD) return 'outside';
  const avg = (imageData.data[i] + imageData.data[i+1] + imageData.data[i+2]) / 3;
  if (avg < WALL_DARK_THRESHOLD) return 'wall';
  return 'floor';
}

// Convert percentage coords (0-100) to pixel coords in the image
function pctToPixel(xPct, yPct, imgMeta, canvasW, canvasH) {
  // imgMeta: { x, y, width, height } all in % of container
  const localX = (xPct - imgMeta.x) / imgMeta.width;  // 0-1 within image
  const localY = (yPct - imgMeta.y) / imgMeta.height;
  return {
    px: Math.round(localX * canvasW),
    py: Math.round(localY * canvasH),
  };
}

// Is a percentage-space point walkable?
function isWalkable(xPct, yPct, imageData, outsideMask, imgMeta, canvasW, canvasH) {
  if (!imgMeta) return true;
  // Reject anything outside the image boundary
  if (xPct < imgMeta.x || xPct > imgMeta.x + imgMeta.width ||
      yPct < imgMeta.y || yPct > imgMeta.y + imgMeta.height) return false;
  if (!imageData) return true;
  const { px, py } = pctToPixel(xPct, yPct, imgMeta, canvasW, canvasH);
  return classifyPixel(px, py, imageData, canvasW, canvasH, outsideMask) === 'floor';
}

// Check if the straight-line path from (x0,y0) to (x1,y1) is clear (no walls/outside)
// Returns last clear point before any obstacle
function traceMove(x0, y0, x1, y1, imageData, outsideMask, imgMeta, canvasW, canvasH, steps = 20) {
  let lastGood = { x: x0, y: y0 };
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = x0 + (x1 - x0) * t;
    const y = y0 + (y1 - y0) * t;
    if (isWalkable(x, y, imageData, outsideMask, imgMeta, canvasW, canvasH)) {
      lastGood = { x, y };
    } else {
      break;
    }
  }
  return lastGood;
}

// Check that a point is near at least 3 wall/line pixels within search radius
// This ensures the asset is inside a room (surrounded by walls on multiple sides)
function isRoomInterior(px, py, imageData, outsideMask, w, h, radius = 18) {
  const directions = [
    [1, 0], [-1, 0], [0, 1], [0, -1],
    [1, 1], [-1, -1], [1, -1], [-1, 1]
  ];
  let wallSidesFound = 0;
  for (const [dx, dy] of directions) {
    for (let r = 2; r <= radius; r++) {
      const c = classifyPixel(px + dx * r, py + dy * r, imageData, w, h, outsideMask);
      if (c === 'wall' || c === 'outside') {
        wallSidesFound++;
        break;
      }
    }
    if (wallSidesFound >= 6) return true;
  }
  return false;
}

// Find a random walkable ROOM INTERIOR position within the image bounds
function findWalkablePos(imgMeta, imageData, outsideMask, canvasW, canvasH, attempts = 200) {
  for (let i = 0; i < attempts; i++) {
    const x = imgMeta.x + Math.random() * imgMeta.width;
    const y = imgMeta.y + Math.random() * imgMeta.height;
    const { px, py } = pctToPixel(x, y, imgMeta, canvasW, canvasH);
    if (classifyPixel(px, py, imageData, canvasW, canvasH, outsideMask) === 'floor' &&
        (!imageData || isRoomInterior(px, py, imageData, outsideMask, canvasW, canvasH))) {
      return { x, y };
    }
  }
  return { x: imgMeta.x + imgMeta.width / 2, y: imgMeta.y + imgMeta.height / 2 };
}

// Deterministic starting position for an asset — must be in a room interior
function deterministicWalkablePos(asset, imgMeta, imageData, outsideMask, canvasW, canvasH) {
  let hash = 0;
  const id = asset.ble_tag_id || asset.asset_id || asset.id || '';
  for (let i = 0; i < id.length; i++) { hash = ((hash << 5) - hash) + id.charCodeAt(i); hash |= 0; }
  for (let i = 0; i < 200; i++) {
    const t = (Math.abs(hash + i * 2654435761) >>> 0) / 4294967295;
    const s = (Math.abs(hash * 1664525 + i * 1013904223) >>> 0) / 4294967295;
    const x = imgMeta.x + t * imgMeta.width;
    const y = imgMeta.y + s * imgMeta.height;
    const { px, py } = pctToPixel(x, y, imgMeta, canvasW, canvasH);
    if (classifyPixel(px, py, imageData, canvasW, canvasH, outsideMask) === 'floor' &&
        (!imageData || isRoomInterior(px, py, imageData, outsideMask, canvasW, canvasH))) {
      return { x, y };
    }
  }
  return findWalkablePos(imgMeta, imageData, outsideMask, canvasW, canvasH);
}

// ── Fake asset generator ─────────────────────────────────────────────────────
function generateFakeAssets(count) {
  const types = Object.keys(EQUIPMENT_ABBR);
  const statuses = ['available', 'available', 'in_use', 'in_use', 'in_use', 'maintenance', 'missing'];
  return Array.from({ length: count }, (_, i) => ({
    id: `fake-${i}`,
    asset_id: `DEMO-${String(i + 1).padStart(3, '0')}`,
    asset_name: `Demo ${EQUIPMENT_LABELS[types[i % types.length]]} ${i + 1}`,
    equipment_type: types[i % types.length],
    status: statuses[i % statuses.length],
    isFake: true,
  }));
}

// ── Main component ────────────────────────────────────────────────────────────
export default function Simulation() {
  const { floorConfig } = useFloorConfig();
  const [selectedFloor, setSelectedFloor] = useState('1');
  const [simulating, setSimulating] = useState(false);
  const [simState, setSimState] = useState({});
  const [hoveredAsset, setHoveredAsset] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [mapReady, setMapReady] = useState(false);

  // Pan / zoom
  const [zoom, setZoom] = useState(0);
  const [zoomInput, setZoomInput] = useState('0');
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [mapFocused, setMapFocused] = useState(false);
  const dragStart = useRef(null);
  const containerRef = useRef(null);

  // Mesh data refs
  const imageDataRef = useRef(null);
  const outsideMaskRef = useRef(null);
  const canvasSizeRef = useRef({ w: 0, h: 0 });
  const imgMetaRef = useRef(null); // { x, y, width, height } in pct

  const { data: realAssets = [] } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const currentFloorConfig = floorConfig.find(f => f.id === selectedFloor) || floorConfig[0];
  const mapImages = currentFloorConfig?.mapImages || [];

  const floorRealAssets = useMemo(() => realAssets.filter(a => a.floor === selectedFloor), [realAssets, selectedFloor]);
  const fakeAssets = useMemo(() => generateFakeAssets(Math.max(0, 30 - floorRealAssets.length)), [floorRealAssets.length]);
  const allAssets = useMemo(() => [...floorRealAssets, ...fakeAssets], [floorRealAssets, fakeAssets]);

  // ── Load image into offscreen canvas for mesh analysis ───────────────────
  useEffect(() => {
    setMapReady(false);
    setSimState({});
    imageDataRef.current = null;
    outsideMaskRef.current = null;
    imgMetaRef.current = null;

    if (!mapImages.length) { setMapReady(true); return; }

    const primary = mapImages[0];
    // Always treat image as filling the full container for walkability calculations
    imgMetaRef.current = { x: 0, y: 0, width: 100, height: 100 };

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const W = img.naturalWidth, H = img.naturalHeight;
      const canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      try {
        const idata = ctx.getImageData(0, 0, W, H);
        imageDataRef.current = idata;
        canvasSizeRef.current = { w: W, h: H };
        outsideMaskRef.current = buildOutsideMask(idata, W, H);
      } catch {
        imageDataRef.current = null;
      }
      setMapReady(true);
    };
    img.onerror = () => { setMapReady(true); };
    img.src = primary.url;
  }, [mapImages]);

  // ── Initialize asset positions once mesh is ready ────────────────────────
  useEffect(() => {
    if (!mapReady) return;
    const imgMeta = imgMetaRef.current;
    const imageData = imageDataRef.current;
    const { w, h } = canvasSizeRef.current;

    setSimState(() => {
      const next = {};
      const outsideMask = outsideMaskRef.current;
      allAssets.forEach(asset => {
        const pos = imgMeta
          ? deterministicWalkablePos(asset, imgMeta, imageData, outsideMask, w, h)
          : { x: 50, y: 50 };
        next[asset.id] = { pos, status: asset.status || 'in_use' };
      });
      return next;
    });
  }, [mapReady, allAssets]);

  // ── Simulation tick ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!simulating || !mapReady) return;

    const interval = setInterval(() => {
      const imgMeta = imgMetaRef.current;
      const imageData = imageDataRef.current;
      const outsideMask = outsideMaskRef.current;
      const { w, h } = canvasSizeRef.current;

      setSimState(prev => {
        const next = { ...prev };
        allAssets.forEach(asset => {
          const cur = next[asset.id];
          if (!cur) return;
          const { pos, status } = cur;

          if (Math.random() > 0.5) {
            const target = imgMeta
              ? findWalkablePos(imgMeta, imageData, outsideMask, w, h, 80)
              : { x: 50, y: 50 };

            const arrived = imgMeta
              ? traceMove(pos.x, pos.y, target.x, target.y, imageData, outsideMask, imgMeta, w, h, 30)
              : target;

            const moved = Math.abs(arrived.x - pos.x) > 0.05 || Math.abs(arrived.y - pos.y) > 0.05;
            const newStatus = moved && status !== 'maintenance'
              ? (status === 'missing' ? 'available' : 'in_use')
              : status;

            next[asset.id] = { pos: moved ? arrived : pos, status: newStatus };
          }
        });
        return next;
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [simulating, mapReady, allAssets]);

  // ── Pan/Zoom ──────────────────────────────────────────────────────────────
  const actualScale = 1 + (zoom / 100) * 3;

  const clampPan = useCallback((p, scale) => {
    if (!containerRef.current) return p;
    const cw = containerRef.current.offsetWidth;
    const ch = containerRef.current.offsetHeight;
    const maxX = Math.max(0, (scale - 1) * cw / 2);
    const maxY = Math.max(0, (scale - 1) * ch / 2);
    return { x: Math.max(-maxX, Math.min(maxX, p.x)), y: Math.max(-maxY, Math.min(maxY, p.y)) };
  }, []);

  const applyZoom = (z) => {
    setZoom(z); setZoomInput(z.toString());
    setPan(p => clampPan(p, 1 + (z / 100) * 3));
  };

  const handleWheel = useCallback((e) => {
    if (!mapFocused) return;
    e.preventDefault();
    applyZoom(Math.max(0, Math.min(300, zoom + (e.deltaY > 0 ? -10 : 10))));
  }, [zoom, clampPan, mapFocused]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  const handleMouseDown = (e) => { setDragging(true); dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y }; };
  const handleMouseMove = (e) => {
    if (containerRef.current) {
      const r = containerRef.current.getBoundingClientRect();
      setMousePos({ x: e.clientX - r.left, y: e.clientY - r.top });
    }
    if (dragging && dragStart.current)
      setPan(clampPan({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y }, actualScale));
  };
  const handleMouseUp = () => { setDragging(false); dragStart.current = null; };

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Hospital Simulation" subtitle="Wall-aware 2D asset movement using floor map mesh">
        <div className="flex items-center gap-3">
          <Select value={selectedFloor} onValueChange={v => { setSelectedFloor(v); setSimulating(false); setSimState({}); }}>
            <SelectTrigger className="w-[130px] bg-card"><SelectValue /></SelectTrigger>
            <SelectContent>
              {floorConfig.map(f => <SelectItem key={f.id} value={f.id}>{f.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant={simulating ? 'default' : 'outline'} onClick={() => setSimulating(s => !s)} className="gap-2">
            {simulating ? <><Pause className="w-4 h-4" /> Stop</> : <><Play className="w-4 h-4" /> Start</>}
          </Button>
          <Button variant="ghost" onClick={() => { setSimulating(false); setSimState({}); setMapReady(false); setTimeout(() => setMapReady(true), 10); }} className="gap-2">
            <RotateCcw className="w-4 h-4" /> Reset
          </Button>
        </div>
      </PageHeader>

      <div className="bg-card rounded-xl border border-border overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div>
            <h3 className="text-sm font-semibold text-foreground">{currentFloorConfig?.label || `Floor ${selectedFloor}`}</h3>
            <span className="text-xs text-muted-foreground">
              {allAssets.length} assets · {mapReady ? (mapImages.length ? 'Wall mesh active' : 'No map') : 'Loading mesh…'}
              {simulating && ' · Simulation running'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {simulating && <span className="text-xs text-primary animate-pulse mr-2">● Live</span>}
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => applyZoom(Math.max(0, zoom - 10))}><ZoomOut className="w-4 h-4" /></Button>
            <input
              type="number" min="0" max="300" value={zoomInput}
              onChange={e => setZoomInput(e.target.value)}
              onBlur={e => applyZoom(Math.max(0, Math.min(300, parseInt(e.target.value) || 0)))}
              onKeyDown={e => e.key === 'Enter' && applyZoom(Math.max(0, Math.min(300, parseInt(e.target.value) || 0)))}
              className="w-16 h-7 text-xs text-center border border-border rounded bg-card focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <span className="text-xs text-muted-foreground">%</span>
            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => applyZoom(Math.min(300, zoom + 10))}><ZoomIn className="w-4 h-4" /></Button>
            <Button size="icon" variant="ghost" className="h-7 w-7 ml-1" onClick={() => { setZoom(0); setZoomInput('0'); setPan({ x: 0, y: 0 }); }}><Maximize2 className="w-4 h-4" /></Button>
          </div>
        </div>

        {/* Map */}
        <div
          ref={containerRef}
          className="relative overflow-hidden bg-muted/30"
          style={{ height: '580px', cursor: dragging ? 'grabbing' : (mapFocused ? 'grab' : 'default') }}
          onClick={() => setMapFocused(true)}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => { handleMouseUp(); setHoveredAsset(null); setMapFocused(false); }}
        >
          <div style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${actualScale})`,
            transformOrigin: 'center center',
            width: '100%', height: '100%',
            transition: dragging ? 'none' : 'transform 0.2s ease',
          }}>
            {mapImages.length === 0 ? (
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-center p-8">
                  <p className="text-sm font-semibold text-foreground mb-1">No Map Uploaded</p>
                  <p className="text-xs text-muted-foreground">Upload a floor map in Admin → Floor Maps to enable wall-aware simulation.</p>
                </div>
              </div>
            ) : (
              <div className="relative w-full h-full">
                {mapImages.map((img, idx) => (
                  <img key={idx} src={img.url} alt={`map-${idx}`}
                    style={{ position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', objectFit: 'fill' }}
                    className="select-none" draggable={false}
                  />
                ))}

                {/* Asset dots */}
                {mapReady && allAssets.map(asset => {
                  const state = simState[asset.id];
                  if (!state) return null;
                  const { pos, status } = state;
                  const color = STATUS_COLOR[status] || '#6b7280';
                  const isMissing = status === 'missing';
                  const abbr = EQUIPMENT_ABBR[asset.equipment_type] || 'OT';
                  const isHovered = hoveredAsset?.id === asset.id;

                  return (
                    <div key={asset.id}
                      onMouseEnter={() => setHoveredAsset(asset)}
                      onMouseLeave={() => setHoveredAsset(null)}
                      style={{
                        position: 'absolute',
                        left: `${pos.x}%`, top: `${pos.y}%`,
                        transform: 'translate(-50%, -50%)',
                        transition: simulating ? 'left 2.4s ease-in-out, top 2.4s ease-in-out' : 'none',
                        zIndex: isHovered ? 50 : 10,
                      }}
                      className="cursor-pointer"
                    >
                      {isMissing ? (
                        <div className="rounded-full border-2 border-dashed flex items-center justify-center"
                          style={{ borderColor: '#ef4444', width: 20, height: 20 }}>
                          <span style={{ fontSize: 6, color: '#ef4444', fontWeight: 700 }}>{abbr}</span>
                        </div>
                      ) : (
                        <div className="rounded-full border-2 border-white shadow-lg flex items-center justify-center"
                          style={{ background: color, width: 20, height: 20 }}>
                          <span style={{ fontSize: 6, color: 'white', fontWeight: 700 }}>{abbr}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Tooltip */}
          {hoveredAsset && simState[hoveredAsset.id] && (
            <div style={{ position: 'absolute', left: mousePos.x + 14, top: mousePos.y + 14, pointerEvents: 'none', zIndex: 9999 }}
              className="bg-card border border-border rounded-lg p-2.5 shadow-xl">
              <div className="text-xs font-semibold text-foreground">{hoveredAsset.asset_name}</div>
              <div className="text-[10px] text-primary font-medium">{EQUIPMENT_LABELS[hoveredAsset.equipment_type] || hoveredAsset.equipment_type}</div>
              {hoveredAsset.department && <div className="text-[10px] text-muted-foreground">{DEPT_LABELS[hoveredAsset.department] || hoveredAsset.department}</div>}
              <div className="text-[10px] font-medium mt-0.5" style={{ color: STATUS_COLOR[simState[hoveredAsset.id]?.status] }}>
                {simState[hoveredAsset.id]?.status?.replace('_', ' ')}
              </div>
              {hoveredAsset.isFake && <div className="text-[10px] text-muted-foreground italic">Demo asset</div>}
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="px-4 py-3 border-t border-border space-y-2">
          <div className="flex flex-wrap gap-3">
            {Object.entries(EQUIPMENT_ABBR).map(([type, abbr]) => (
              <div key={type} className="flex items-center gap-1 text-xs text-muted-foreground">
                <span className="w-5 h-5 rounded-full bg-muted flex items-center justify-center font-bold text-[9px] text-foreground border border-border">{abbr}</span>
                {EQUIPMENT_LABELS[type]}
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-4 items-center pt-1 border-t border-border/50">
            {[{ label: 'Available', color: '#10b981' }, { label: 'In Use', color: '#3b82f6' }, { label: 'Maintenance', color: '#f59e0b' }, { label: 'Missing', dashed: true }].map(item => (
              <div key={item.label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                {item.dashed
                  ? <span className="w-3 h-3 rounded-full border-2 border-dashed" style={{ borderColor: '#ef4444' }} />
                  : <span className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />}
                {item.label}
              </div>
            ))}
            <span className="text-xs text-muted-foreground ml-auto">Dark lines = walls · Assets path-check before moving · Scroll to zoom · Drag to pan</span>
          </div>
        </div>
      </div>
    </div>
  );
}