import React, { useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LineChart, Line, PieChart, Pie } from 'recharts';
import PageHeader from '../components/layout/PageHeader';
import StatCard from '../components/dashboard/StatCard';
import { Package, Activity, Wrench, Clock } from 'lucide-react';

const DEPT_LABELS = {
  emergency: 'ER', icu: 'ICU', surgery: 'Surgery', radiology: 'Radiology',
  cardiology: 'Cardio', pediatrics: 'Peds', oncology: 'Onco',
  neurology: 'Neuro', orthopedics: 'Ortho', general_ward: 'General',
  outpatient: 'Outpat.', storage: 'Storage',
};

const TYPE_LABELS = {
  infusion_pump: 'Infusion Pump', patient_monitor: 'Monitor', wheelchair: 'Wheelchair',
  ventilator: 'Ventilator', defibrillator: 'Defibrillator', ultrasound: 'Ultrasound',
  portable_xray: 'X-Ray', bed: 'Bed', stretcher: 'Stretcher', other: 'Other',
};

const COLORS = [
  'hsl(199, 89%, 48%)', 'hsl(172, 66%, 50%)', 'hsl(262, 52%, 55%)',
  'hsl(43, 96%, 56%)', 'hsl(0, 72%, 51%)', 'hsl(199, 89%, 65%)',
  'hsl(330, 65%, 55%)', 'hsl(120, 40%, 50%)', 'hsl(190, 60%, 45%)',
  'hsl(43, 96%, 70%)',
];

export default function Reports() {
  const { data: assets = [] } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const { data: locationHistory = [] } = useQuery({
    queryKey: ['location-history-all'],
    queryFn: () => base44.entities.LocationHistory.list('-created_date', 500),
  });

  const { data: maintenanceRequests = [] } = useQuery({
    queryKey: ['maintenance-all'],
    queryFn: () => base44.entities.MaintenanceRequest.list('-created_date', 200),
  });

  // Equipment type distribution
  const typeData = useMemo(() => {
    const counts = {};
    assets.forEach(a => { counts[a.equipment_type] = (counts[a.equipment_type] || 0) + 1; });
    return Object.entries(counts).map(([type, count]) => ({
      name: TYPE_LABELS[type] || type, value: count,
    })).sort((a, b) => b.value - a.value);
  }, [assets]);

  // Department usage (based on movements)
  const deptMovements = useMemo(() => {
    const counts = {};
    locationHistory.forEach(l => { counts[l.department] = (counts[l.department] || 0) + 1; });
    return Object.entries(counts).map(([dept, count]) => ({
      name: DEPT_LABELS[dept] || dept, movements: count,
    })).sort((a, b) => b.movements - a.movements);
  }, [locationHistory]);

  // Utilization - % of assets in_use per department
  const utilizationData = useMemo(() => {
    const deptAssets = {};
    const deptInUse = {};
    assets.forEach(a => {
      if (a.department) {
        deptAssets[a.department] = (deptAssets[a.department] || 0) + 1;
        if (a.status === 'in_use') deptInUse[a.department] = (deptInUse[a.department] || 0) + 1;
      }
    });
    return Object.keys(deptAssets).map(dept => ({
      name: DEPT_LABELS[dept] || dept,
      utilization: Math.round(((deptInUse[dept] || 0) / deptAssets[dept]) * 100),
    })).sort((a, b) => b.utilization - a.utilization);
  }, [assets]);

  const inUseCount = assets.filter(a => a.status === 'in_use').length;
  const utilRate = assets.length ? Math.round((inUseCount / assets.length) * 100) : 0;
  const openMaint = maintenanceRequests.filter(r => r.status === 'open' || r.status === 'in_progress').length;

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Reports & Analytics" subtitle="Equipment utilization and operational insights" />

      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard title="Total Assets" value={assets.length} icon={Package} />
        <StatCard title="Utilization Rate" value={`${utilRate}%`} icon={Activity} />
        <StatCard title="Total Movements" value={locationHistory.length} icon={Clock} />
        <StatCard title="Open Maintenance" value={openMaint} icon={Wrench} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Equipment Type Distribution */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Equipment Type Distribution</h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={typeData} layout="vertical" margin={{ left: 70, right: 20 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} width={65} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid hsl(214 20% 90%)' }} />
                <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                  {typeData.map((_, idx) => <Cell key={idx} fill={COLORS[idx % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Department Utilization */}
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Department Utilization Rate</h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={utilizationData} margin={{ left: -10, right: 20 }}>
                <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid hsl(214 20% 90%)' }} formatter={(v) => `${v}%`} />
                <Bar dataKey="utilization" radius={[6, 6, 0, 0]} fill="hsl(199, 89%, 48%)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Movement frequency */}
      <div className="bg-card rounded-xl border border-border p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">Movement Frequency by Department</h3>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={deptMovements} margin={{ left: -10, right: 20 }}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid hsl(214 20% 90%)' }} />
              <Bar dataKey="movements" radius={[6, 6, 0, 0]}>
                {deptMovements.map((_, idx) => <Cell key={idx} fill={COLORS[idx % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}