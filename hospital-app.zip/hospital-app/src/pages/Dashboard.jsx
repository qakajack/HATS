import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Package, Radio, AlertTriangle, Wrench, Activity, Search } from 'lucide-react';
import PageHeader from '../components/layout/PageHeader';
import StatCard from '../components/dashboard/StatCard';
import DepartmentChart from '../components/dashboard/DepartmentChart';
import StatusPieChart from '../components/dashboard/StatusPieChart';
import RecentAlerts from '../components/dashboard/RecentAlerts';
import RecentActivity from '../components/dashboard/RecentActivity';
import AssetDrilldownModal from '../components/dashboard/AssetDrilldownModal';
import { Input } from '@/components/ui/input';
import { useNavigate } from 'react-router-dom';

export default function Dashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = React.useState('');
  const [drilldown, setDrilldown] = useState(null); // { title, assets }

  const { data: assets = [], isLoading: loadingAssets } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-updated_date', 500),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.list('-created_date', 50),
  });

  const { data: locationHistory = [] } = useQuery({
    queryKey: ['location-history'],
    queryFn: () => base44.entities.LocationHistory.list('-created_date', 20),
  });

  const { data: maintenanceRequests = [] } = useQuery({
    queryKey: ['maintenance-requests'],
    queryFn: () => base44.entities.MaintenanceRequest.filter({ status: 'open' }),
  });

  const activeAlerts = alerts.filter(a => a.status === 'active').length;
  const inMaintenance = assets.filter(a => a.status === 'maintenance').length;
  const available = assets.filter(a => a.status === 'available').length;
  const lowBattery = assets.filter(a => a.battery_level != null && a.battery_level < 20);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/Assets?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const openDrilldown = (title, filtered) => setDrilldown({ title, assets: filtered });

  if (loadingAssets) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto">
      <PageHeader title="Dashboard" subtitle="Hospital Asset Tracking System overview">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Quick search assets..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-9 w-64 bg-card"
          />
        </form>
      </PageHeader>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Total Assets" value={assets.length} icon={Package}
          onClick={() => openDrilldown('All Assets', assets)}
        />
        <StatCard
          title="Available" value={available} icon={Activity}
          trend={`${assets.length ? Math.round((available / assets.length) * 100) : 0}%`} trendUp
          onClick={() => openDrilldown('Available Assets', assets.filter(a => a.status === 'available'))}
